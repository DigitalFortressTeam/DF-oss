//SEARCH STRATEGIES
#include "functions.h"
void tornado_right(){
    rotate_right(180, false);
    if(IR_FR_READ == 0 || IR_FL_READ == 0){
        robot_state = ATTACK;
    }
}

void tornado_left(){
    rotate_left(180, false);
    if(IR_FR_READ == 0 || IR_FL_READ == 0){
        robot_state = ATTACK;
    }

}

void random_search(){
   
}

void slow_search(){

}

void counter_attack(){
    
}









const int motorLEN = 7;
const int motorREN = 9;
const int motorL_PWM = 11;
const int motorR_PWM = 12;
const int GROUND_BL = 14;
const int GROUND_BR = A15;
const int GROUND_FL = 10;
const int GROUND_FR = 15;
int GROUND_BL_READ;
int GROUND_BR_READ;
int GROUND_FL_READ;
int GROUND_FR_READ;
int IR_L_READ;
int IR_R_READ;
int IR_FL_READ;
int IR_FR_READ;
const int buzzer = 6;
const int IR_L = A7;
const int IR_R = 16;
const int IR_FR = 25;
const int IR_FL = A1;

const int START = 0;
const int STOP = 4;
const int launching = 7;
const int ATTACK = 1;
const int GROUND = 2;
const int ROTATE_RIGHT = 3;
const int ROTATE_LEFT = 5;
const int SEARCH = 6;
int robot_state = SEARCH;

int remember_right = 0;
int remember_left = 0;

bool run1time = 1;
int fullspeed = 0;
bool accelerating = 0;
byte accelerating_speed = 129;

unsigned long t2 = 0;
unsigned long t3 = 0;

int amount = 0;
unsigned long t1 = 0;

bool countering = 0;

float current_pwm;

float smoothedpwm = 128;

unsigned long t4 = 0;

bool groundedr = 0;
bool groundedl = 0;